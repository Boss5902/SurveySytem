

<?php $__env->startSection('main-content'); ?>   
       
    <?php if(Auth::user()->role_id === 2): ?>

             <b style="color:green">Welcome to Staff Area</b>

    <?php elseif(Auth::user()->role_id === 1): ?> 
            <div class="container">
                <div class="col-md-5 ">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-success table-striped" border="1px">
                                <thead>
                                    <tr style="text-align: center;">
                                        <th scope="col">Total Questions</th>
                                        <th scope="col">Total Users</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="text-align: center;"> 
                                            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <b style="color: green"><?php echo e($item->total_que); ?></b>   
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td style="text-align: center;"> 
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <b style="color: green;"> <?php echo e($item->total_user); ?></b>   
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
     <?php endif; ?>   
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administration.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bdd.SENZA\Desktop\SurveySystem\resources\views/administration/subdash.blade.php ENDPATH**/ ?>