


<?php $__env->startSection('sidebar'); ?>
            <div class="sidebar-sticky">            
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <a class="d-flex align-items-center text-muted" href="<?php echo e(route('subdash')); ?>">

                        <?php if(Auth::user()->role_id === 2): ?>
                            <span data-feather="plus-circle">STAFF Dashboard</span>
                        <?php elseif(Auth::user()->role_id === 1): ?>
                            <span data-feather="plus-circle">Management Dashboard</span>
                        <?php endif; ?>
                        
                    </a>
                </h6>
                <ul class="nav flex-column mb-2">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('survey')); ?>">
                            <span data-feather="file-text"></span>
                            Survey Module
                        </a>
                    </li>
                </ul>
            </div>   
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
              <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
              <?php endif; ?>              
              <?php echo $__env->yieldContent('main-content'); ?>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administration.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bdd.SENZA\Desktop\SurveySystem\resources\views/administration/dashboard.blade.php ENDPATH**/ ?>