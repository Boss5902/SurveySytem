
<?php $__env->startSection('main-content'); ?>   

      <?php if(Auth::user()->role_id === 2): ?>
            
            <?php if(session('error')): ?>
                  <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div> 
            <?php elseif($submitted == true): ?>
                <h3 style="color:green">Your Survey Allready Submiited</h3>    
            <?php endif; ?>
            
            <div class="container"> 
            <div class="row">
                  <div class="col-md-6">
                        
                        <div class="card">
                        <div class="card-header">
                              Survey Form  
                        </div>
                        <div class="card-body"> 
                              <form action="<?php echo e(route('survey.post')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    
                                    <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="user_id">
                                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-3"> 
                                          
                                                <label class="form-label"><?php echo e($item->question); ?></label><br>
                                                
                                                <?php if($item->type == 'select'): ?>
                                                    <select name="answer[<?php echo e($item->id); ?>]" class="form-control">
                                                        <?php $__currentLoopData = $item->answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($itm->question_id == $item->id && $item->type == 'select'): ?>   
                                                                    <option value="<?php echo e($itm->id); ?>"><?php echo e($itm->name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php endif; ?>

                                                <?php $__currentLoopData = $item->answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($itm->question_id == $item->id && $item->type == 'checkbox'): ?>   
                                                            <input type="checkbox" name="answer[<?php echo e($item->id); ?>][]" value="<?php echo e($itm->id); ?>" class="form-check-control" ><?php echo e($itm->name); ?><br>
                                                        <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <?php if($item->type == 'text'): ?>   
                                                        <input type="text" value="" name="answer[<?php echo e($item->id); ?>]" class="form-control" />        
                                                <?php elseif($item->type == 'date'): ?>   
                                                        <input type="date" value="" name="answer[<?php echo e($item->id); ?>]" class="form-control" />
                                                <?php elseif($item->type == 'textarea'): ?>   
                                                        <textarea class="form-control" rows="3" name="answer[<?php echo e($item->id); ?>]"></textarea>
                                                <?php endif; ?>
                                        </div>        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                          <?php if($submitted === true): ?>
                                                
                                          <?php else: ?>
                                                  <input type="submit" name="post" value="Submit">
                                          <?php endif; ?>      
                                              
                              </form>
                        </div>
                        </div>
                  </div>
            </div>
            </div>  

      <?php elseif(Auth::user()->role_id === 1): ?> 
    
            <div class="container">
                <div class="col-md-5 ">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-success table-striped" border="1px">
                                <thead>
                                    <tr style="text-align: center;">
                                        <th scope="col"><b>Question Name</b></th>
                                        <th scope="col"><b>Attempted Users</b></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php $__currentLoopData = $quesAttemptByUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question => $Attuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr  style="text-align: center;">
                                          <td><b style="color: green"> Question <?php echo e($question); ?></b></td>
                                          <td><b style="color: green"><?php echo e($Attuser); ?></b></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
      <?php endif; ?>        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administration.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bdd.SENZA\Desktop\SurveySystem\resources\views/administration/survey.blade.php ENDPATH**/ ?>